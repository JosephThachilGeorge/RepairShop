package logic;


    public  interface Service {

        Void calculatecost();
        Void display();
        Void expecteddeliverydate();
        Void discount();


    }

